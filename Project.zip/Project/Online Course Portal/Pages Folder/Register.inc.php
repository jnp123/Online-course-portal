<html>
<head>

<title>form</title>

<style type="text/css">
h1{color:red;}
p{color:blue;} 
term {
    background: transparent;
    border: none;
  }
</style>

</head>

<body>
<legend>Register</legend><br>
<fieldset>

<form method="POST" action="">



<p>
<label for="email">Email:</label><br>
<input type="email" name="Email" placeholder="email id"><br>
</p>

<p>
<label for="firstname">Firstname:</label><br>
<input type="text" name="Firstname" placeholder="firstname"><br>
</p>

<p>
<label for="lastname">Lastame:</label><br>
<input type="text" name="Lastame" placeholder="lastname"><br>
</p>


<p>
<label for="password">Password:</label><br>
<input type="password" name="Password" placeholder="Enter password">
</p>

<p>
<label for="password">Confirm Password:</label><br>
<input type="password" name="ConfirmPassword" placeholder="Retype password"><br>
</p>

<p>
<label for="mobile">Mobile:</label><br>
<input type="mobile" name="Mobile" placeholder="Mobile number"><br>
</p>

<p>
<label for="noaccount">Create an account-></label>
<input type="submit" name="submit" value="Register">
</p>


<?php
	//Establishing Connection with Server
	$connection = mysqli_connect("localhost", "user", "user123","project");

	if(isset($_POST["submit"]))
{
   
	//Fetching variables of the form which travels in URL
    
    $Email = $_POST["Email"];
    $Firstname = $_POST["Firstname"];
    $Lastame = $_POST["Lastame"];
	$password = $_POST["Password"];
    $ConfirmPassword = $_POST["ConfirmPassword"];
    $Mobile = $_POST["Mobile"];
    
	
	if($Email!=""&&$Mobile!="")
	{		
	
	
	//Insert Query of SQL
   
	
	 $sql = "INSERT INTO register VALUES ('$Email', '$Firstname', '$Lastame', '$password', '$ConfirmPassword', '$Mobile')";
   
	
	 if (mysqli_query($connection, $sql))
	 {
     echo "<br/><br/><span>Data Inserted successfully...!!</span>";;
     } 
	 else 
	 {
     echo "Error: " . $sql . "<br>" . mysqli_error($connection);
     }
	}
 }

	//Closing Connection with Server
	mysqli_close($connection);
?>					

</form>
</fieldset>
</body>
</html>

